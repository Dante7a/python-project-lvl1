print("Welcome to the Brain Games")
